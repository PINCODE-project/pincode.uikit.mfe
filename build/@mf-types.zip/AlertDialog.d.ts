export * from './compiled-types/components/ui/alert-dialog';
export { default } from './compiled-types/components/ui/alert-dialog';