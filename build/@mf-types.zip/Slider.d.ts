export * from './compiled-types/components/ui/slider';
export { default } from './compiled-types/components/ui/slider';