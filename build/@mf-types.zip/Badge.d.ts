export * from './compiled-types/components/ui/badge';
export { default } from './compiled-types/components/ui/badge';