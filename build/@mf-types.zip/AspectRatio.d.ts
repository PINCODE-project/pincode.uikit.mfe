export * from './compiled-types/components/ui/aspect-ratio';
export { default } from './compiled-types/components/ui/aspect-ratio';