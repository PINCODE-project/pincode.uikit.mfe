export * from './compiled-types/components/ui/input-otp';
export { default } from './compiled-types/components/ui/input-otp';