export * from './compiled-types/components/ui/tabs';
export { default } from './compiled-types/components/ui/tabs';