export * from './compiled-types/components/ui/pagination';
export { default } from './compiled-types/components/ui/pagination';