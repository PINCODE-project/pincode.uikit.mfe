export * from './compiled-types/components/ui/collapsible';
export { default } from './compiled-types/components/ui/collapsible';