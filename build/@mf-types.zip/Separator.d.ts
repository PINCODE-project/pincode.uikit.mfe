export * from './compiled-types/components/ui/separator';
export { default } from './compiled-types/components/ui/separator';