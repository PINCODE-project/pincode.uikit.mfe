export * from './compiled-types/components/ui/switch';
export { default } from './compiled-types/components/ui/switch';