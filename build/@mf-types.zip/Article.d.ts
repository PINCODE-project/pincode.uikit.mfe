export * from './compiled-types/components/ui/article/Article';
export { default } from './compiled-types/components/ui/article/Article';