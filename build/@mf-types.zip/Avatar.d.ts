export * from './compiled-types/components/ui/avatar';
export { default } from './compiled-types/components/ui/avatar';