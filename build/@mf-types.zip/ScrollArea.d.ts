export * from './compiled-types/components/ui/scroll-area';
export { default } from './compiled-types/components/ui/scroll-area';