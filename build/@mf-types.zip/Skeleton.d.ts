export * from './compiled-types/components/ui/skeleton';
export { default } from './compiled-types/components/ui/skeleton';