export * from './compiled-types/components/ui/label';
export { default } from './compiled-types/components/ui/label';