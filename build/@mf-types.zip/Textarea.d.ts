export * from './compiled-types/components/ui/textarea';
export { default } from './compiled-types/components/ui/textarea';