export * from './compiled-types/components/ui/table';
export { default } from './compiled-types/components/ui/table';