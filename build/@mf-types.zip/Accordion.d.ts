export * from './compiled-types/components/ui/accordion';
export { default } from './compiled-types/components/ui/accordion';