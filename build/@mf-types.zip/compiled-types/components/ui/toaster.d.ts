export declare function Toaster(): import("react/jsx-runtime").JSX.Element;
