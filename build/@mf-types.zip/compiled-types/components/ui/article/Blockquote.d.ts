import React from "react";
interface BlockquoteProps {
    children: React.ReactNode;
    className?: string;
}
export declare function Blockquote({ children, className }: BlockquoteProps): import("react/jsx-runtime").JSX.Element;
export {};
