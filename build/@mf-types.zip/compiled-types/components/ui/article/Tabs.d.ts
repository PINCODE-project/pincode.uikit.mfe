import React from "react";
interface TabsCodeProps {
    tabs: {
        label: string;
        children: React.ReactNode;
    }[];
}
export declare function Tabs({ tabs }: TabsCodeProps): import("react/jsx-runtime").JSX.Element;
export {};
