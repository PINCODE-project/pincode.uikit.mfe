import { ArticleContent } from "@/components/ui/article/Article";
interface ColumnsProps {
    content: ArticleContent[][];
    className?: string;
}
export declare function Columns({ content, className }: ColumnsProps): import("react/jsx-runtime").JSX.Element | null;
export {};
