import React from "react";
interface LiveComponentProps {
    component: React.ReactNode;
    className?: string;
}
export declare function LiveComponent({ component, className }: LiveComponentProps): import("react/jsx-runtime").JSX.Element;
export {};
