interface CodeBlockProps {
    children: string;
    language?: string;
    className?: string;
}
export declare function CodeBlock({ children, language, className }: CodeBlockProps): import("react/jsx-runtime").JSX.Element;
export {};
