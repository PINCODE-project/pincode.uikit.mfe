interface ImageProps {
    src: string;
    alt: string;
    className?: string;
}
export declare function Image({ src, alt, className }: ImageProps): import("react/jsx-runtime").JSX.Element;
export {};
