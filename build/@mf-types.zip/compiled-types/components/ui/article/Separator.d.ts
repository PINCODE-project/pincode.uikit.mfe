interface SeparatorProps {
    className?: string;
}
export declare function Separator({ className }: SeparatorProps): import("react/jsx-runtime").JSX.Element;
export {};
